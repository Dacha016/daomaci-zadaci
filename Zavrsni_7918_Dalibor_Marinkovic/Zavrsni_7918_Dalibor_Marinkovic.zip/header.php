<div class="container-fluid wrapper nav">
    <div class="row" >
        <div class="d-flex justify-content-center align-items-center col-12 col-sm-12 d-md-none dropdown">
            <a href="index.php" class="headline p-2 p-sm-2 d-md-none float-sm-right dropdown-toggle" data-toggle="dropdown">Menu</a>
            <div class="dropdown-menu">
                <a href="index.php" class="d-sm-block dropdown-item ">Home</a>
                <a href="folowers.php" class="d-sm-block dropdown-item ">Friends</a>
                <a href="changeProfile.php" class="d-sm-block dropdown-item ">Change profile</a>
                <a href="changePass.php" class="d-sm-block dropdown-item ">Change passwors</a>
                <a href="logout.php" class="d-sm-block dropdown-item ">Logout</a>
            </div> 
        </div> 
        <nav class="d-none d-sm-none d-md-block" >
            <ul>
                <li>
                    <a class="p-2" href="index.php">Home</a>
                </li>
                <li>
                    <a class="p-2" href="followers.php">Friends</a>
                </li>
                <li>
                    <a class="p-2" href="changeProfile.php">Change profile</a>
                </li>
                <li>
                    <a class="p-2" href="changePass.php">Change passwors</a>
                </li>
                <li>
                    <a class="p-2" href="logout.php">Logout</a>
                </li>
            </ul>
        </nav>
    </div>
</div>
    