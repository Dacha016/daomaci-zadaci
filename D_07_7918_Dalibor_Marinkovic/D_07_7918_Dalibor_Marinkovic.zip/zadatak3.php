<?php
$p = 2000;
$m = 5000;
$cena = 1500;
$peraK = $p-$cena;
$mikaK = $m-$cena;
echo "Kusur koji treba da dobije Pera je ".$peraK." dinara";
echo "<br>";
echo "Kusur koji treba da dobije Mika je ".$mikaK." dinara";
?>