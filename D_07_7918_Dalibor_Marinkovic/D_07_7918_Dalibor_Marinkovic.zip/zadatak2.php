<?php
$n = 10;
$a =2;
$prviDan = $a;
$drugiDan = $prviDan + 2;
$preostalaPoglavlja = $n-($prviDan+$drugiDan);
echo "Ostala su jos ".$preostalaPoglavlja." poglavlja";
?>